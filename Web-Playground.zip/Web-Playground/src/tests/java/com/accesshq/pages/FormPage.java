package com.accesshq.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class FormPage extends BasePage {

	public FormPage(WebDriver driver) {
		super(driver);
	}
	
	public void clickSubmit()
	{
		List<WebElement> buttonElements = driver.findElements(By.cssSelector(".modern button"));
		for(WebElement button : buttonElements)
		{
			if(button.getText().equals("SUBMIT"))
			{
				button.click();
			}
		}
	}
	
	
	public String getErrorName()
	{
		return driver.findElement(By.id("name-err")).getText();
	}
	public String getErrorEmail()
	{
		return driver.findElement(By.id("email-err")).getText();
	}
	
	public String getErrorAgree()
	{
		return driver.findElement(By.id("agree-err")).getText();
	}
	
	public void setName(String name)
	{
		driver.findElement(By.name("name")).sendKeys(name);
	}
	public void setAgree()
	{
		driver.findElement(By.cssSelector(".v-input [aria-hidden='true']")).click();
		
	}

}
