package com.accesshq.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.accesshq.pages.FormPage;
import com.accesshq.pages.HomePage;

class HomeTest extends BaseTestSuite{

	@Test
	void testMandatoryError() {
		HomePage clickForm = new HomePage(driver);
		clickForm.clickForms();
		
		FormPage formPage = new FormPage(driver);
		formPage.clickSubmit();
		
		assertEquals(formPage.getErrorName(), "Your name is required");
		assertEquals(formPage.getErrorEmail(), "Your email is required");
		assertEquals(formPage.getErrorAgree(), "You must agree to continue");
		
		formPage.setName("elie");
	}

}
