package com.accesshq.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;

import com.accesshq.pages.FormPage;

class FormTest extends BaseTestSuite{

	@Test
	void testMandatoryError() {
		
	}

}
